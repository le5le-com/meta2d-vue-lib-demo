<template>
  <div class="Home">
    <router-view />
  </div>
</template>

<script setup lang="ts"></script>

<style>
.Home {
  height: 100vh;
  position: relative;
}
</style>
